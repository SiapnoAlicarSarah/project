<?php
namespace App\Models;

use App\Database;
use PDO;

class StaffApproval
{
    private $conn;

    public function __construct()
    {
        $db = new Database();
        $this->conn = $db->connection();
    }

    public function statusOf($userId)
    {
        $stmt = $this->conn->prepare("SELECT status FROM staff WHERE user_id=? LIMIT 1");
        $stmt->execute([$userId]);
        return $stmt->fetchColumn();
    }

    public function isApproved($userId)
    {
        return $this->statusOf($userId) === "approved";
    }

    public function pending()
    {
        return $this->conn->query(
            "SELECT u.user_id, u.name, u.email, u.created_at
             FROM staff s JOIN users u ON u.user_id = s.user_id
             WHERE s.status = 'pending'
             ORDER BY u.created_at"
        )->fetchAll(PDO::FETCH_ASSOC);
    }

    public function approved()
    {
        return $this->conn->query(
            "SELECT u.user_id, u.name, u.email, s.hire_date
             FROM staff s JOIN users u ON u.user_id = s.user_id
             WHERE s.status = 'approved'
             ORDER BY u.name"
        )->fetchAll(PDO::FETCH_ASSOC);
    }

    public function setStatus($userId, $status)
    {
        if (!in_array($status, ["approved", "rejected"], true)) {
            return "Invalid status.";
        }
        try {
            $this->conn->prepare("UPDATE staff SET status=? WHERE user_id=?")
                       ->execute([$status, $userId]);
            return $status === "approved" ? "Staff approved." : "Staff access removed.";
        } catch (\PDOException $e) {
            return "Could not update staff: " . $e->getMessage();
        }
    }
}