<?php
// expects $sub from staff_top.php
$clientMessage = $_SESSION["client_message"] ?? "";
unset($_SESSION["client_message"]);

if (isset($_POST["update_client"])) {
    $uid = (int) ($_POST["user_id"] ?? 0);
    $name = trim($_POST["name"] ?? "");
    $email = trim($_POST["email"] ?? "");
    if ($name === "" || $email === "") {
        $_SESSION["client_message"] = "Name and email are required.";
    } else {
        $_SESSION["client_message"] = $sub->updateClient($uid, $name, $email);
    }
    header("Location: " . $_SERVER["PHP_SELF"]);
    exit;
}

if (isset($_POST["delete_client"])) {
    $uid = (int) ($_POST["user_id"] ?? 0);
    $_SESSION["client_message"] = $sub->deleteClient($uid);
    header("Location: " . $_SERVER["PHP_SELF"]);
    exit;
}

$clients = $sub->allClients();

// what the View popup shows for each client
$viewData = [];
foreach ($clients as $c) {
    $bd = $c["birthdate"] ?? "";
    $viewData[(int) $c["user_id"]] = [
        "name"      => $c["name"],
        "email"     => $c["email"],
        "contact"   => ($c["contact_number"] ?? "") !== "" ? $c["contact_number"] : "Not set",
        "address"   => ($c["address"] ?? "") !== "" ? $c["address"] : "Not set",
        "birthdate" => ($bd !== "" && $bd !== "0000-00-00") ? date("M d, Y", strtotime($bd)) : "Not set",
        "emergency" => ($c["emergency_contact"] ?? "") !== "" ? $c["emergency_contact"] : "Not set",
        "since"     => !empty($c["created_at"]) ? date("M d, Y", strtotime($c["created_at"])) : "—",
        "plan"      => $c["current_plan"] ?: "No active membership",
        "expires"   => !empty($c["current_end"]) ? date("M d, Y", strtotime($c["current_end"])) : "—",
        "paid"      => "₱" . number_format((float) $c["total_paid"], 2),
    ];
}
?>
<section class="card" id="clients">
    <div class="card-head"><div><h2>Clients</h2><p class="muted">Manage client accounts.</p></div></div>
    <?php if ($clientMessage !== ""): ?>
        <p><?= htmlspecialchars($clientMessage) ?></p>
    <?php endif; ?>

    <?php if (empty($clients)): ?>
        <p>No clients yet.</p>
    <?php else: ?>
        <table>
            <tr><th>Name</th><th>Email</th><th>Action</th></tr>
            <?php foreach ($clients as $c): ?>
                <tr>
                    <td><?= htmlspecialchars($c["name"]) ?></td>
                    <td><?= htmlspecialchars($c["email"]) ?></td>
                    <td>
                        <form method="POST" style="display:inline-flex; gap:6px; align-items:center;">
                            <input type="hidden" name="user_id" value="<?= (int) $c["user_id"] ?>">
                            <input type="text" name="name" value="<?= htmlspecialchars($c["name"]) ?>" required>
                            <input type="email" name="email" value="<?= htmlspecialchars($c["email"]) ?>" required>
                            <button type="submit" name="update_client">Save</button>
                        </form>
                        <form method="POST" style="display:inline;" onsubmit="return confirm('Delete this client?');">
                            <input type="hidden" name="user_id" value="<?= (int) $c["user_id"] ?>">
                            <button type="submit" name="delete_client" class="btn-danger">Delete</button>
                            <button type="button" class="view-client btn-secondary" data-id="<?= (int) $c["user_id"] ?>">View</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
        </table>
    <?php endif; ?>
</section>

<!-- View client popup -->
<dialog id="viewClientDialog" style="max-width:480px; width:92%;">
    <h2 id="vcName">Client</h2>
    <p class="muted" id="vcEmail"></p>

    <h3 style="margin-top:14px;">Contact Details</h3>
    <div class="info-row"><span>Contact number</span><span id="vcContact"></span></div>
    <div class="info-row"><span>Address</span><span id="vcAddress"></span></div>
    <div class="info-row"><span>Birthdate</span><span id="vcBirthdate"></span></div>
    <div class="info-row"><span>Emergency contact</span><span id="vcEmergency"></span></div>

    <h3 style="margin-top:14px;">Membership</h3>
    <div class="info-row"><span>Member since</span><span id="vcSince"></span></div>
    <div class="info-row"><span>Current plan</span><span id="vcPlan"></span></div>
    <div class="info-row"><span>Expires</span><span id="vcExpires"></span></div>
    <div class="info-row"><span>Total paid</span><span id="vcPaid"></span></div>

    <br>
    <button type="button" id="closeViewClient" class="btn-cancel">Close</button>
</dialog>

<script>
    var clientView = <?= json_encode($viewData, JSON_HEX_TAG | JSON_HEX_AMP) ?>;
    var viewClientDialog = document.getElementById("viewClientDialog");

    function setText(id, value) { document.getElementById(id).textContent = value; }

    document.querySelectorAll(".view-client").forEach(function (btn) {
        btn.onclick = function () {
            var d = clientView[btn.dataset.id];
            if (!d) { return; }
            setText("vcName", d.name);
            setText("vcEmail", d.email);
            setText("vcContact", d.contact);
            setText("vcAddress", d.address);
            setText("vcBirthdate", d.birthdate);
            setText("vcEmergency", d.emergency);
            setText("vcSince", d.since);
            setText("vcPlan", d.plan);
            setText("vcExpires", d.expires);
            setText("vcPaid", d.paid);
            viewClientDialog.showModal();
        };
    });
    document.getElementById("closeViewClient").onclick = function () { viewClientDialog.close(); };
</script>