<?php
// Expects $pendingStaff and $approvedStaff from ownerDashboard.php
$pendingStaff  = $pendingStaff  ?? [];
$approvedStaff = $approvedStaff ?? [];
?>

<dialog id="staffApprovalDialog" style="max-width:820px; width:92%;">
    <h2>Staff Approvals</h2>

    <h3>Waiting for Approval</h3>
    <?php if (empty($pendingStaff)): ?>
        <p class="empty">No staff are waiting for approval.</p>
    <?php else: ?>
        <div class="table-wrap">
            <table>
                <tr><th>Name</th><th>Email</th><th>Registered</th><th>Action</th></tr>
                <?php foreach ($pendingStaff as $s): ?>
                    <tr>
                        <td><?= htmlspecialchars($s["name"] ?? "") ?></td>
                        <td><?= htmlspecialchars($s["email"] ?? "") ?></td>
                        <td><?= !empty($s["created_at"]) ? date("M d, Y", strtotime($s["created_at"])) : "-" ?></td>
                        <td>
                            <form method="POST" style="display:flex; gap:6px; margin:0; flex-direction:row;">
                                <input type="hidden" name="user_id" value="<?= (int) $s["user_id"] ?>">
                                <button type="submit" name="approve_staff">Approve</button>
                                <button type="submit" name="reject_staff" class="btn-danger"
                                        onclick="return confirm('Reject this staff account?');">Reject</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </table>
        </div>
    <?php endif; ?>

    <h3 style="margin-top:20px;">Approved Staff</h3>
    <?php if (empty($approvedStaff)): ?>
        <p class="empty">No approved staff yet.</p>
    <?php else: ?>
        <div class="table-wrap">
            <table>
                <tr><th>Name</th><th>Email</th><th>Hired</th><th>Action</th></tr>
                <?php foreach ($approvedStaff as $s): ?>
                    <tr>
                        <td><?= htmlspecialchars($s["name"] ?? "") ?></td>
                        <td><?= htmlspecialchars($s["email"] ?? "") ?></td>
                        <td><?= !empty($s["hire_date"]) ? date("M d, Y", strtotime($s["hire_date"])) : "-" ?></td>
                        <td>
                            <form method="POST" style="margin:0; flex-direction:row;">
                                <input type="hidden" name="user_id" value="<?= (int) $s["user_id"] ?>">
                                <button type="submit" name="revoke_staff" class="btn-danger"
                                        onclick="return confirm('Revoke this staff member\'s access?');">Revoke</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </table>
        </div>
    <?php endif; ?>

    <br>
    <button type="button" id="closeStaffApproval">Close</button>
</dialog>

<script>
    var staffApprovalDialog = document.getElementById("staffApprovalDialog");
    var openStaffApprovals  = document.getElementById("openStaffApprovals");
    var closeStaffApproval  = document.getElementById("closeStaffApproval");
    if (openStaffApprovals) openStaffApprovals.onclick = function () { staffApprovalDialog.showModal(); };
    if (closeStaffApproval) closeStaffApproval.onclick = function () { staffApprovalDialog.close(); };
</script>